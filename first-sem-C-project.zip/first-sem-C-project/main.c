#include<stdio.h>
#include<string.h>
#include"strings.h"
#include"operaters.h"
#include"operatersheader.h"
#include<stdlib.h>
#include<conio.h>
#include"mother.h"
#include"loops.h"
#include"loopsheader.h"
#include"Cstatements.h"
#include"Cstatementsheader.h"
#include"someproblems.h"
#include"someproblemsheader.h"


void mainFunction();
int main()
{
    printf("                                      INTERFACE COLLAGE OF COMPUTER APPLICATIONS      \n\n\n");
    printf("Hello sir welcome to our project\n");
    printf("Sir our project topics are:\n");
    printf("OPERATERS\n");
    printf("CONDITIONAL STATEMENTS\n");
    printf("LOOPS\n");
    printf("STRINGS\n");
    mainFunction();

}
void mainFunction()
{
    int choice;
    printf("*********************************************************\n");
    printf("  Here we call these are the main project concepts     \n");
    printf("  Enter 1 to know about the operaters                  \n");
    printf("  Enter 2 to know about the conditional statemente     \n");
    printf("  Enter 3 to know about the loops                      \n");
    printf("  Enter 4 to know about the strings                    \n");
    printf("  Enter 5 to know some prograns on all concepts        \n");
    printf("*********************************************************\n");

    printf("Enter the choice:\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:operatersMainFunction();break;
        case 2:conditionalStatenentsMF();break;
        case 3:loopsMainFunction();break;
        case 4:stringsMainFunction();break;
        case 5:somePrograms();break;
        default :printf("Please enter the currect choice\n");break;
    }
}

